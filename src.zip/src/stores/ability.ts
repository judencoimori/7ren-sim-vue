import { ref } from 'vue'
import { defineStore } from 'pinia'

export const useAbilityStore = defineStore('ability', () => {
    const defaultAbility = { id:0, name: "", function: "", type: "", level: { level: "", option: "" } };
    const partnerAbilitys = ref(new Array([defaultAbility]));
    const enemyAbilitys = ref(new Array());
    const abilityData = ref(new Array());
    function addAnima() {
        partnerAbilitys.value.push([{id:0, name: "", function: "", type: "", level: { level: "", option: "" } }]);
    }
    function addAbility(animaNum: number, id:number) {
        const addAbility = { id: id, name: "", function: "", type: "", level: { level: "", option: "" } };
        partnerAbilitys.value[animaNum].push(addAbility);
    }
    function removeAbility(animaNum: number, abilityNum: number) {
        partnerAbilitys.value[animaNum].splice(abilityNum, 1);
    }
    function checkAbility(animaNum: number, abilityNum: number) {
        for (let i = 0; i < abilityData.value.length; i++) {
            if (abilityData.value[i].name === partnerAbilitys.value[animaNum][abilityNum].name) {
                partnerAbilitys.value[animaNum][abilityNum].function = abilityData.value[i].function;
                partnerAbilitys.value[animaNum][abilityNum].type = abilityData.value[i].type;
                return;
            }
            resetAbility(animaNum, abilityNum);
        }
    }
    function resetAbility(animaNum: number, abilityNum: number) {
        partnerAbilitys.value[animaNum][abilityNum].function = "";
        partnerAbilitys.value[animaNum][abilityNum].type = "";
        partnerAbilitys.value[animaNum][abilityNum].level = { level: "", option: "" };
    }

    return { partnerAbilitys, abilityData, addAnima, addAbility, removeAbility, checkAbility }
})