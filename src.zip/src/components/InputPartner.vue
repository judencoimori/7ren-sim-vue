<script setup lang="ts">
import AbilityInputErea from './AbilityInputErea.vue';
import SelectAnima from "./SelectAnima.vue"
interface Props {
    animaNum: number;
}
const props = defineProps<Props>();
</script>

<template>
    <p>アニマ選択エリア</p>
    <SelectAnima></SelectAnima>
    <p>ステータス入力エリア</p>
    <p>アビリティ入力エリア</p>
    <AbilityInputErea :animaNum="props.animaNum"></AbilityInputErea>
</template>

<style>
p {
    margin:0;
}</style>