<script setup lang="ts">
import { ref, computed } from "vue";
import { getAnimaData } from "../composables/getAnimaData.js";

const animaData = getAnimaData();
const element = ref("b");
const rank = ref("CD");

const narrowAnimaData = computed(
    () => {
        return animaData.value.filter(anima => {
            return anima.rank == rank.value && anima.element == element.value;
        })
    }
)
const selectedAnimaId = ref("");
const selectedAnimaStatus = computed(
    () => {
        const anima = animaData.value[parseInt(selectedAnimaId.value)];
        return {
            hp: anima.hp,
            atk:anima.atk,
            def:anima.def,
            spd:anima.spd,
            luk:anima.luk
        }
    }
)

</script>

<template>
    <div>
        <input type="radio" name="element" id="beast" v-model="element" value="b"><label for="beast">獣</label>
        <input type="radio" name="element" id="magic" v-model="element" value="m"><label for="magic">魔</label>
        <input type="radio" name="element" id="golem" v-model="element" value="g"><label for="golem">ゴ</label>
        <input type="radio" name="element" id="dragon" v-model="element" value="d"><label for="dragon">竜</label>
        <input type="radio" name="element" id="nothing" v-model="element" value="n"><label for="nothing">無</label>
    </div>
    <div>
        <input type="radio" name="rank" id="SS" v-model="rank" value="SS"><label for="SS">SS</label>
        <input type="radio" name="rank" id="S" v-model="rank" value="S"><label for="S">S</label>
        <input type="radio" name="rank" id="A" v-model="rank" value="A"><label for="A">A</label>
        <input type="radio" name="rank" id="B" v-model="rank" value="B"><label for="B">B</label>
        <input type="radio" name="rank" id="CD" v-model="rank" value="CD"><label for="CD">CD</label>
    </div>
    <div>
        <label for="selectAnima">アニマ選択</label>
        <select id="selectAnima" v-model="selectedAnimaId">
            <option v-for="anima in narrowAnimaData" :value="anima.id">{{ anima.name }}</option>
        </select>
    </div>
</template>

<style>
#selectAnima {
    width: 100%;
}
</style>