<script setup lang="ts">
import { ref, computed } from "vue";
import { useAbilityStore } from '@/stores/ability';
import { storeToRefs } from 'pinia';

interface Props {
    ability: Object;
    abilityNum: number;
    animaNum: number;
}
const props = defineProps<Props>();

const ability = useAbilityStore();
const { abilityData, partnerAbilitys } = storeToRefs(ability);
const { checkAbility, removeAbility } = ability;

const isNotAbility = ref(false);

const options = computed(
    (): string[] => {
        const abilityName = partnerAbilitys.value[props.animaNum][props.abilityNum].name;
        const abilityIndex = abilityData.value.findIndex(element => element.name == abilityName);
        if (abilityIndex >= 0) {
            isNotAbility.value = false;
            return abilityData.value[abilityIndex].option;
        }
        if (abilityName != "") isNotAbility.value = true;
        return [];
    }
);

const getIdStr = computed(
    (): string => {
        const IdStr: string = "ability" + props.animaNum + "_" + props.abilityNum
        return IdStr;
    }
);

</script>

<template>
    <div class="abilityInputFormContainer">
        <label :for="getIdStr">{{ abilityNum + 1 }}</label>
        <input type="text" v-model.lazy="partnerAbilitys[animaNum][abilityNum].name" list="abilityOptions"
            @change="checkAbility(animaNum, abilityNum)" :id="getIdStr" :class="{ bgColorPink: isNotAbility }">
        <select v-model="partnerAbilitys[animaNum][abilityNum].level">
            <option disabled value="">-</option>
            <option v-for="(option, index) in options" :key="index" :value="{ level: index + 1, option: option }">{{ index +
                1 }}
            </option>
        </select>
        <button @click="removeAbility(animaNum, abilityNum)">x</button>
    </div>
</template>

<style>
.bgColorPink {
    background-color: pink;
}

.abilityInputFormContainer {
    display: flex;
    align-items: center;
    container-type: inline-size;
}

@container (min-width:300px) {
    label {
        color: red;
    }
}

label,
button {
    height:2em;
    margin: 0 2px 0 0;
}

input,
select {
    height: 2em;
    margin: 0 2px 0 0;
}

input {
    flex: 1 1 auto;
}

select {
    flex: 0 0 3em;
    width: 2.5em;
}
</style>