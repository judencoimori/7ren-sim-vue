<script setup lang="ts">
import { ref, onMounted } from 'vue';
import AbilityInputForm from './AbilityInputForm.vue'
import { useAbilityStore } from '@/stores/ability';
import { storeToRefs } from 'pinia';


interface Props {
    animaNum: number;
}
const props = defineProps<Props>();

const ability = useAbilityStore();
const { partnerAbilitys, abilityData } = storeToRefs(ability);
const { addAbility } = ability;
const id = 1;
/*
onMounted(
    (): void => {
        fetch("../public/data/abilityData.csv")
            .then((response) => response.text())
            .then((data) => {
                let lines = data.split(/\r\n|\n/);
                for (let i = 0; i < lines.length; i++) {
                    let cells = lines[i].split(",");
                    abilityData.value[i] = {
                        function: cells[0],
                        name: cells[1],
                        type: cells[2],
                        option: cells.slice(3, 8).filter((n: string) => n != "")
                    }
                }
                let datalist = document.getElementById("abilityOptions")!;
                for (let i = 0; i < abilityData.value.length; i++) {
                    let option = document.createElement("option");
                    option.value = abilityData.value[i].name;
                    datalist.appendChild(option);
                }
            })
            .catch((err) => console.log(`err:${err}`));
    }
);
*/
</script>

<template>
    <div>
        <button @click="addAbility(props.animaNum, id), id++">Add ability</button>
        <TransitionGroup tag="div">
            <AbilityInputForm v-for="(ability, index) in partnerAbilitys[props.animaNum]" :key="ability.id" :ability="ability"
                :abilityNum="index" :animaNum="props.animaNum">
            </AbilityInputForm>
        </TransitionGroup>
    </div>
</template>

<style>
.v-move,
.v-enter-active,
.v-leave-active {
    transition: all 0.5s ease;
}

.v-enter-from,
.v-leave-to {
    opacity: 0;
    transform: translateX(30px);
}
.v-leave-active {
  position: absolute;
}
</style>