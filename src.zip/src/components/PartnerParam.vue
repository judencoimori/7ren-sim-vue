<script setup lang="ts">
import { computed } from '@vue/reactivity';
import { useAbilityStore } from '@/stores/ability';
import { storeToRefs } from 'pinia';
const ability = useAbilityStore();
const { partnerAbilitys } = storeToRefs(ability);
const animaNum = computed(
    (): number => {
        return partnerAbilitys.value.length;
    }
)

</script>

<template>
    <div>
        <div v-for="n in animaNum">
            <p v-for="(ability, index) in partnerAbilitys[n-1]">
                {{ index + 1 }}:{{ ability.name }}({{ ability.level.level }})
            </p>
        </div>
    </div>
</template>