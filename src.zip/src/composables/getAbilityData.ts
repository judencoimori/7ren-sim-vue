import { storeToRefs } from 'pinia';
import { useAbilityStore } from '@/stores/ability';

export async function getAbilityData() {
    const ability = useAbilityStore();
    const { abilityData } = storeToRefs(ability);
    const ABILITY_DATA_URL:string = "../public/data/abilityData.csv";

    fetch(ABILITY_DATA_URL)
    .then((res) => res.text())
    .then((text) => {
      const lines = text.split(/\r\n|\n/);
      for(let i = 0; i < lines.length; i++) {
        let cells = lines[i].split(",");
        abilityData.value[i] = {
            function: cells[0],
            name: cells[1],
            type: cells[2],
            option: cells.slice(3, 8).filter((n: string) => n != "")
        }
      }
      let datalist = document.getElementById("abilityOptions")!;
      for (let i = 0; i < abilityData.value.length; i++) {
          let option = document.createElement("option");
          option.value = abilityData.value[i].name;
          datalist.appendChild(option);
      }
    })
    .catch((err) => (console.log(err)));
}