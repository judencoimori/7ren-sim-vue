import { ref, isRef, unref, watchEffect, type Ref } from "vue";

export async function useFetchCsv(url: string | Ref<string>) {
  const data:Ref<string[][]>|Ref<null> = ref(null);
  const error:any = ref(null);

  function doFetch() {
    data.value = null;
    error.value = null;
    fetch(unref(url))
      .then((res) => res.text())
      .then((text) => {
        const lines = text.split(/\r\n|\n/);
        for(let i = 0; i < lines.length; i++) {
          console.log(i);
          data.value![i] = lines[i].split(",");
        }
      })
      .catch((err) => (error.value = err));
  }

  if (isRef(url)) {
    watchEffect(doFetch);
  } else {
    doFetch();
  }

  return { data, error };
}
