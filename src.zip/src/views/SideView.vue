<script setup lang="ts">
import PartnerParam from '../components/PartnerParam.vue';
</script>

<template>
    <div>
        <slot></slot>
        <PartnerParam></PartnerParam>
    </div>
</template>