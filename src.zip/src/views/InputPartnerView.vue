<script setup lang="ts">
import { ref, onMounted } from "vue";
import InputPartner from "../components/InputPartner.vue";
import { useAbilityStore } from '@/stores/ability';
import {getAbilityData} from "../composables/getAbilityData.js"

const ability = useAbilityStore();
const { addAnima } = ability;
const animaCount = ref(1);
onMounted(
    ():void => {
        getAbilityData();
    }
)

function increaceAnima() {
    animaCount.value++;
    addAnima();
}
</script>

<template>
    <div>
        <div v-for="n in animaCount">
            <p>{{ n }}体目</p>
            <InputPartner :animaNum="n - 1"></InputPartner>
        </div>
        <button @click="increaceAnima">Add Anima</button>
    </div>
</template>