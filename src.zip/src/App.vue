<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import SideView from './views/SideView.vue';
</script>

<template>
  <header>
    <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="30" height="30" />
    header
  </header>
  <div class="main">
    <SideView class="sideview">
      <nav>
        <RouterLink to="/">InputPartner</RouterLink>
      </nav>
    </SideView>
    <RouterView class="routerview"/>
  </div>
</template>

<style scoped>
header {
  background-color: gray;
}
.main{
  display:flex;
}
.sideview {
  width:200px;
}
.routerview {
  flex:1 1 100%;
}
</style>
